#!/usr/bin/env python3
"""
Generate 200 diverse Thai guides with scattered specialties across all locations
Ensures beach, food, and other specialties are well-distributed

Usage:
    python3 generate_200_guides.py

Requirements:
    - AWS credentials configured
    - DynamoDB guides table deployed via Terraform
    - Set environment variables or use default naming convention
"""

import boto3
import random
import os
import sys
from datetime import datetime
from decimal import Decimal

# Configuration from environment or defaults
AWS_REGION = os.getenv('AWS_REGION', 'eu-west-1')
PROJECT_NAME = os.getenv('PROJECT_NAME', 'thailand-guide-bot')
ENVIRONMENT = os.getenv('ENVIRONMENT', 'dev')

# Construct table name using naming convention
GUIDES_TABLE_NAME = os.getenv('GUIDES_TABLE_NAME', f'{PROJECT_NAME}-{ENVIRONMENT}-guides')

print(f"🌍 Region: {AWS_REGION}")
print(f"📊 Guides Table: {GUIDES_TABLE_NAME}")

try:
    dynamodb = boto3.resource('dynamodb', region_name=AWS_REGION)
    guides_table = dynamodb.Table(GUIDES_TABLE_NAME)
    
    # Test table access
    guides_table.load()
    print(f"✅ Connected to DynamoDB table: {GUIDES_TABLE_NAME}")
except Exception as e:
    print(f"❌ Error connecting to DynamoDB table '{GUIDES_TABLE_NAME}': {e}")
    print(f"💡 Make sure:")
    print(f"   • AWS credentials are configured")
    print(f"   • Table exists: {GUIDES_TABLE_NAME}")
    print(f"   • Region is correct: {AWS_REGION}")
    print(f"   • Or set environment variables:")
    print(f"     export GUIDES_TABLE_NAME=your-table-name")
    print(f"     export AWS_REGION=your-region")
    sys.exit(1)

# Thai names categorized by gender
FEMALE_NAMES = [
    "Ploy", "Apinya", "Malee", "Nattaya", "Suda", "Pranee", "Anchalee", 
    "Siriporn", "Duangjai", "Rattana", "Chanya", "Supaporn", "Kanokwan", 
    "Anong", "Darika", "Fasai", "Hansa", "Lamai", "Manee", "Orathai", 
    "Pimchan", "Qwan", "Ratchanee", "Tida", "Wanida", "Yingluck", "Zara",
    "Busaba", "Chanida", "Dara", "Fon", "Ganya", "Jinda", "Kanya", "Lawan",
    "Mali", "Nida", "Porn", "Ratana", "Siri", "Thida", "Usa", "Vanna"
]

MALE_NAMES = [
    "Somchai", "Niran", "Krit", "Wichai", "Narong", "Somkid", "Thawat",
    "Chalerm", "Prasert", "Wasan", "Boonmee", "Pongsakorn", "Kamon",
    "Boonlert", "Chaiwat", "Ekachai", "Gamon", "Ittiporn", "Jira", "Kamol",
    "Sarawut", "Udom", "Vichit", "Anuwat", "Bancha", "Chatchai", "Danai",
    "Ekkachai", "Fah", "Grit", "Hiran", "Itthipol", "Jaran", "Kasem"
]

thai_names = FEMALE_NAMES + MALE_NAMES

VIDEO_KEYS = {
    'female': 'videos/guide_female.mp4',
    'male': 'videos/guide_male.mp4'
}

VIDEO_URLS = {
    'female': 'https://tinyurl.com/thaiguidef',
    'male': 'https://tinyurl.com/thaiguidem'
}

thai_surnames = [
    "Thanakit", "Photiwat", "Siriporn", "Wongsakul", "Kanjana", "Saengchai",
    "Pimchan", "Rattana", "Chaiwong", "Suwan", "Sombat", "Panya", "Thong",
    "Boonma", "Kaew", "Wattana", "Boonlert", "Saetang", "Chaiyo", "Pimpa",
    "Saelim", "Ruangsri", "Wira", "Chai", "Srisai", "Kaewmanee", "Boonmee",
    "Srisawat", "Pattana", "Mongkol", "Suwannarat", "Charoensuk", "Phongphan",
    "Boonsong", "Chaiwan", "Damrong", "Ekkarat", "Fongchai", "Gamon", "Hiran"
]

# Locations with distribution (200 total)
locations = {
    "Bangkok": 60,
    "Phuket": 50,
    "Pattaya": 50,
    "Chiang Mai": 40
}

# COMPREHENSIVE specialty sets - scattered across ALL locations
# Each location gets a mix of everything
ALL_SPECIALTIES = [
    # Beach & Water (20% of guides)
    ["beach", "island hopping", "snorkeling", "swimming"],
    ["beach clubs", "water sports", "jet ski", "parasailing"],
    ["diving", "marine life", "underwater photography", "coral reefs"],
    ["island tours", "boat trips", "sunset cruises", "beach walks"],
    ["beach activities", "kayaking", "paddleboarding", "beach volleyball"],
    
    # Food (20% of guides)
    ["street food", "food tours", "local markets", "eating"],
    ["cooking classes", "thai cuisine", "restaurants", "food tasting"],
    ["seafood", "local food", "food markets", "culinary tours"],
    ["cafe hopping", "coffee shops", "desserts", "bakeries"],
    ["night markets", "food stalls", "authentic cuisine", "food adventures"],
    
    # Cultural & Temples (15% of guides)
    ["temples", "cultural tours", "buddhist sites", "wat"],
    ["history", "museums", "royal palaces", "architecture"],
    ["cultural experiences", "traditional ceremonies", "local customs", "heritage"],
    
    # Shopping (10% of guides)
    ["shopping", "malls", "fashion", "bargaining"],
    ["markets", "souvenirs", "handicrafts", "local products"],
    
    # Nightlife (10% of guides)
    ["nightlife", "rooftop bars", "clubs", "entertainment"],
    ["parties", "live music", "shows", "evening entertainment"],
    
    # Nature & Adventure (10% of guides)
    ["trekking", "hiking", "nature", "mountains"],
    ["adventure", "zip-lining", "rafting", "outdoor activities"],
    ["wildlife", "eco-tourism", "animals", "nature tours"],
    
    # Family & Kids (5% of guides)
    ["family tours", "attractions", "theme parks", "kids activities"],
    
    # Luxury & Romance (5% of guides)
    ["luxury tours", "yacht charters", "private experiences", "spa"],
    ["romantic tours", "couples", "sunset", "photography"],
    
    # Wellness (5% of guides)
    ["wellness", "spa", "yoga", "meditation"]
]

languages_pool = [
    ["Thai", "English"],
    ["Thai", "English", "Chinese"],
    ["Thai", "English", "Japanese"],
    ["Thai", "English", "French"],
    ["Thai", "English", "German"],
    ["Thai", "English", "Korean"],
    ["Thai", "English", "Spanish"],
    ["Thai", "English", "Russian"],
    ["Thai", "English", "Chinese", "Japanese"],
    ["Thai", "English", "French", "German"]
]

def determine_gender(first_name):
    """Determine gender from first name"""
    if first_name in FEMALE_NAMES:
        return 'female'
    elif first_name in MALE_NAMES:
        return 'male'
    else:
        return 'male'

def get_regions(location):
    """Get regions for a location"""
    regions_map = {
        "Bangkok": ["Bangkok", "Ayutthaya", "Central Thailand"],
        "Phuket": ["Phuket", "Krabi", "Phi Phi Islands", "Koh Samui"],
        "Pattaya": ["Pattaya", "Jomtien", "Koh Larn", "Rayong"],
        "Chiang Mai": ["Chiang Mai", "Chiang Rai", "Pai", "Mae Hong Son"]
    }
    return regions_map.get(location, [location])

def generate_guides():
    """Generate 200 diverse guides with scattered specialties"""
    
    guide_count = 0
    specialty_index = 0
    
    # First, delete all existing guides
    print("🗑️  Clearing existing guides...")
    scan = guides_table.scan()
    with guides_table.batch_writer() as batch:
        for item in scan['Items']:
            batch.delete_item(Key={'guideId': item['guideId']})
    print("✅ Cleared existing guides")
    
    for location, count in locations.items():
        print(f"\n🌍 Generating {count} guides for {location}...")
        
        for i in range(count):
            guide_count += 1
            
            first_name = random.choice(thai_names)
            name = f"{first_name} {random.choice(thai_surnames)}"
            gender = determine_gender(first_name)
            video_s3_key = VIDEO_KEYS[gender]
            video_url = VIDEO_URLS[gender]
            
            # Rotate through ALL specialties to ensure even distribution
            specialties = ALL_SPECIALTIES[specialty_index % len(ALL_SPECIALTIES)]
            specialty_index += 1
            
            languages = random.choice(languages_pool)
            age = Decimal(random.randint(25, 45))
            experience = Decimal(random.randint(2, 20))
            rating = Decimal(str(round(random.uniform(4.5, 5.0), 1)))
            reviews = Decimal(random.randint(50, 500))
            price = Decimal(random.choice([70, 75, 80, 85, 90, 95, 100, 105, 110, 120, 130, 150]))
            
            guide = {
                'guideId': f'guide_{guide_count:03d}',
                'name': name,
                'gender': gender,
                'video_s3_key': video_s3_key,
                'video_url': video_url,
                'age': age,
                'location': location,
                'regions': get_regions(location),
                'languages': languages,
                'specialties': specialties,
                'experience_years': experience,
                'rating': rating,
                'total_reviews': reviews,
                'price_per_day': price,
                'currency': 'USD',
                'availability': 'available',
                'status': 'active',
                'bio': f"Experienced {location} guide specializing in {', '.join(specialties[:2])}. {experience} years of experience.",
                'created_at': datetime.utcnow().isoformat(),
                'updated_at': datetime.utcnow().isoformat()
            }
            
            guides_table.put_item(Item=guide)
            print(f"  ✅ {name} ({gender}) - {specialties[0]}, {specialties[1]} - ${price}/day")
    
    print(f"\n🎉 Generated {guide_count} guides total!")
    print(f"\n📊 Distribution:")
    for loc, cnt in locations.items():
        print(f"  {loc}: {cnt} guides")
    
    print(f"\n🎯 Specialty Distribution:")
    print(f"  Beach/Water: ~40 guides (20%)")
    print(f"  Food: ~40 guides (20%)")
    print(f"  Cultural: ~30 guides (15%)")
    print(f"  Shopping: ~20 guides (10%)")
    print(f"  Nightlife: ~20 guides (10%)")
    print(f"  Nature: ~20 guides (10%)")
    print(f"  Family: ~10 guides (5%)")
    print(f"  Luxury: ~10 guides (5%)")
    print(f"  Wellness: ~10 guides (5%)")

if __name__ == "__main__":
    print("🚀 Generating 200 Thai guides with scattered specialties...")
    print("⚠️  This will DELETE all existing guides and create new ones!")
    response = input("Continue? (yes/no): ")
    if response.lower() == 'yes':
        generate_guides()
    else:
        print("❌ Cancelled")
