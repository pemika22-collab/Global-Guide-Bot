"""
AgentCore Multi-Agent Orchestration System
Pure multi-agent implementation without Bedrock Agent
"""

__version__ = "1.0.0"
