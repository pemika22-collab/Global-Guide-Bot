AWS AI Agent Global Hackathon
Agents of change - building tomorrows AI solution today
Start project
Find teammates
Import from portfolio
Who can participate
Above legal age of majority in country of residence
All countries/territories, excluding standard exceptions 
View full rules
13 days to deadline
View schedule

Deadline

Oct 21, 2025 @ 2:00am GMT+2 
Online
Public
$45,000 in cash	7706 participants
AWS
Devpost icon rgb30px
Managed by Devpost
DevOps Enterprise Machine Learning/AI
🤖 We are thrilled to invite you to the AWS AI Agent Global Hackathon! This is your chance to dive deep into our powerful generative AI stack and create something truly awesome. We challenge you to build, develop, and deploy a working AI Agent on AWS using cutting-edge tools like Amazon Bedrock, Amazon SageMaker AI, and the Amazon Bedrock AgentCore. It's an exciting opportunity to explore the future of autonomous systems by building agents that use reasoning, connect to external tools and APIs, and execute complex tasks ⚒️

🌱 Participating in this hackathon is an incredible opportunity to showcase your technical prowess, solve real-world problems, and push the boundaries of what's possible with AI. We are looking for novel solutions that are creative, well-architected, and have the potential for measurable impact. Getting started is straightforward: begin by brainstorming a problem your AI agent can solve, explore the required AWS services like Amazon Bedrock or Amazon Q to power your agent's core, and start architecting your solution. Join developers from around the globe, learn new skills, and show us what you can build. We can't wait to see the amazing agents you create ✨

 

 Why You Should Participate
Win Big: Compete for your share of the $45,000 USD in cash prize pool by showcasing your innovative AI solution 💰

Build with Cutting-Edge Tech: Get hands-on experience with the latest AWS generative AI services, including Amazon Bedrock, Amazon SageMaker AI, and powerful agent-building frameworks 🗡️

Solve Real-World Problems: Create an AI agent that has a measurable impact, tackling meaningful challenges in any industry you can imagine 🌐

Showcase Your Skills: Demonstrate your expertise in AI, software architecture, and creative problem-solving to a global audience and our panel of expert judges 👀

 

How to Get Started Now
Brainstorm Your Idea: Think of a process or problem that could be improved or solved by an autonomous AI agent. Consider the judging criteria, focusing on potential impact and creativity 🧠

Review the Tech Stack: Familiarize yourself with the required services (can be found below). Dive into the documentation and explore how to use Large Language Models (LLMs) to power your agent's reasoning capabilities 📚

Form Your Team (Optional): Find collaborators who share your vision. Diverse skill sets in development, architecture, and presentation can make a big difference 🔗

Start Building: Begin architecting your solution on AWS. A great first step is to set up a basic agent that can perform a simple task using an API and a Large Language Model (LLM) 🧰

Requirements
WHAT TO BUILD
Build, develop, and deploy a working AI Agent on AWS. Each working AI agent must meet three conditions below:

Large Language Model (LLM) hosted out of AWS Bedrock or Amazon SageMaker AI. 
Uses one or more of the following AWS services: 
Amazon Bedrock AgentCore - at least 1 primitive (strongly recommended) 
Amazon Bedrock/Nova 
Amazon Q
Amazon SageMaker AI
Amazon SDKs for Agents/Nova Act SDK (Strands Agents, DIY agents using AWS) infrastructure)
AWS Transform
Kiro (leveraged for agent building)
Meets AWS-defined AI agent qualification
Uses reasoning LLMs (or a similar component) for decision-making
Demonstrates autonomous capabilities with or without human inputs for task execution
Integrates APIs, databases, external tools (e.g., web search, code execution, etc.) or other agents
Below are additional helper services that are optional for participants to leverage:

AWS Lambda

Amazon Simple Storage Service (S3)

Amazon API Gateway

We will provide $100 in credit codes for participants on a first come first serve basis to support build cost. The AWS Credits are not applicable to Kiro. *Kiro requires an access code. 

Please note that not all of the AWS Services below are available in every AWS region. You should use the region that best suits your building needs in compliance with any local laws or regulations applicable to you. 

 
WHAT TO SUBMIT
URL to your public code repo - must contain all necessary source code, assets, and instructions required for the project to be functional  

Architecture diagram

Text description 

~3-minute demo video 

URL to your deployed project

 

See Full Rules for Details.

Prizes
$45,000 in prizes
1st Place
$16,000 in cash
1 winner
• $16,000 USD
• White-glove enablement support for AWS Marketplace listings if desired
• Comprehensive marketing support if desired
• GTM support for solutions aligned with AWS prioritized workloads if desired

2nd Place
$9,000 in cash
1 winner
• $9,000 USD
• White-glove enablement support for AWS Marketplace listings if desired
• Comprehensive marketing support if desired
• GTM support for solutions aligned with AWS prioritized workloads if desired

3rd Place
$5,000 in cash
1 winner
• $5,000 USD
• White-glove enablement support for AWS Marketplace listings if desired
• Comprehensive marketing support if desired
• GTM support for solutions aligned with AWS prioritized workloads if desired

Best Amazon Bedrock AgentCore Implementation
$3,000 in cash
1 winner
$3,000 USD

Best Amazon Bedrock Application
$3,000 in cash
1 winner
$3,000 USD

Best Amazon Q Application
$3,000 in cash
1 winner
$3,000 USD

Best Amazon Nova Act Integration
$3,000 in cash
1 winner
$3,000 USD

Best Strands SDK Implementation
$3,000 in cash
1 winner
$3,000 USD