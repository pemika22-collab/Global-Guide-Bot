# Design Document

## Overview

The Global Guide Bot is built on a **pure AWS serverless architecture** using **Amazon Bedrock AgentCore** as the central orchestration platform. The system demonstrates cutting-edge agentic AI capabilities through specialized agents that collaborate autonomously to provide intelligent tourist assistance. The design showcases **100% AWS services** including Lambda (Python), API Gateway, DynamoDB, S3, EventBridge, and SQS, with **Claude 3.5 Sonnet** and **Claude 3 Haiku** providing reasoning capabilities. **Amazon Nova Act** enables multi-modal understanding for visual content analysis, making this a comprehensive demonstration of AWS AI services for the hackathon with **zero third-party dependencies**.

## Architecture

### Pure AWS Serverless Multi-Agent Architecture

```mermaid
graph TB
    subgraph "Tourist Interface"
        WA[WhatsApp Business API]
        APIGW[API Gateway]
    end
    
    subgraph "AWS Serverless Processing"
        LAMBDA1[WhatsApp Webhook Lambda]
        LAMBDA2[Message Router Lambda]
        LAMBDA3[Agent Orchestrator Lambda]
        LAMBDA4[Tourist Agent Lambda]
        LAMBDA5[Cultural Agent Lambda]
        LAMBDA6[Guide Matching Lambda]
        LAMBDA7[Booking Agent Lambda]
        LAMBDA8[QA Agent Lambda]
    end
    
    subgraph "AWS Event-Driven Architecture"
        EB[EventBridge]
        SQS1[Agent Communication Queue]
        SQS2[Booking Processing Queue]
        SQS3[Notification Queue]
    end
    
    subgraph "Amazon Bedrock AI Services"
        CLAUDE35[Claude 3.5 Sonnet]
        CLAUDE3[Claude 3 Haiku]
        NOVA[Amazon Nova Act]
        TRANSLATE[Amazon Translate]
    end
    
    subgraph "AWS Data & Storage"
        DDB1[Users Table]
        DDB2[Guides Table]
        DDB3[Bookings Table]
        DDB4[Messages Table]
        S3[Media Storage]
        CW[CloudWatch Logs]
    end
    
    WA --> APIGW
    APIGW --> LAMBDA1
    LAMBDA1 --> EB
    EB --> LAMBDA2
    LAMBDA2 --> SQS1
    
    SQS1 --> LAMBDA3
    LAMBDA3 --> LAMBDA4
    LAMBDA3 --> LAMBDA5
    LAMBDA3 --> LAMBDA6
    LAMBDA3 --> LAMBDA7
    LAMBDA3 --> LAMBDA8
    
    LAMBDA4 --> CLAUDE35
    LAMBDA5 --> CLAUDE35
    LAMBDA6 --> CLAUDE3
    LAMBDA7 --> CLAUDE3
    LAMBDA8 --> CLAUDE35
    
    LAMBDA6 --> NOVA
    LAMBDA5 --> TRANSLATE
    
    LAMBDA4 --> DDB1
    LAMBDA6 --> DDB2
    LAMBDA7 --> DDB3
    LAMBDA1 --> DDB4
    
    LAMBDA8 --> S3
    LAMBDA3 --> CW
    
    LAMBDA7 --> SQS2
    LAMBDA8 --> SQS3
```

### Component Architecture

The system follows a **pure AWS serverless architecture** pattern:

1. **Presentation Layer**: WhatsApp Business API through API Gateway
2. **Event-Driven Orchestration**: EventBridge and SQS for agent coordination
3. **AI Processing Layer**: Amazon Bedrock AgentCore with specialized Lambda agents
4. **Data Layer**: DynamoDB tables for all persistent storage, S3 for media files
5. **Integration Layer**: AWS services only - CloudWatch, EventBridge, SQS for coordination

## Components and Interfaces

### 1. Messaging Platform Integration

#### WhatsApp Business API Integration
- **Webhook Endpoint**: API Gateway `/webhook/whatsapp`
- **Authentication**: Bearer token validation in Lambda
- **Message Types**: Text, images, videos, quick replies, buttons
- **Rate Limits**: 80 messages per second (Cloud API)
- **Processing**: Direct Lambda function invocation

#### AWS Event-Driven Message Processing
```python
# Message processing in Lambda
import boto3
import json

def lambda_handler(event, context):
    # Parse WhatsApp webhook
    message_data = json.loads(event['body'])
    
    # Send to EventBridge for agent processing
    eventbridge = boto3.client('events')
    eventbridge.put_events(
        Entries=[{
            'Source': 'whatsapp.webhook',
            'DetailType': 'Message Received',
            'Detail': json.dumps(message_data)
        }]
    )
    
    return {'statusCode': 200}
```

### 2. AWS Serverless Agent Architecture

#### Specialized Lambda Agents

**1. Tourist Understanding Agent (Lambda)**
- Processes natural language using Claude 3.5 Sonnet
- Extracts preferences and travel intent
- Maintains conversation context in DynamoDB
- Triggers follow-up questions via EventBridge

**2. Cultural Intelligence Agent (Lambda)**
- Provides Thai cultural guidance using Claude 3.5 Sonnet
- Accesses cultural knowledge base in DynamoDB
- Integrates weather and festival data
- Sends cultural tips via SQS

**3. Guide Matching Agent (Lambda)**
- Analyzes guide profiles using Claude 3 Haiku
- Implements explainable AI ranking algorithms
- Queries guide availability in real-time
- Returns recommendations with reasoning

**4. Booking Coordinator Agent (Lambda)**
- Handles autonomous conflict resolution using Claude 3 Haiku
- Manages scheduling and availability
- Processes booking confirmations
- Coordinates notifications via SQS

**5. Quality Assurance Agent (Lambda)**
- Monitors experience quality using Claude 3.5 Sonnet
- Analyzes feedback and ratings
- Triggers proactive interventions
- Optimizes future recommendations

#### Agent Communication Pattern
```python
# EventBridge-based agent coordination
import boto3

def coordinate_agents(tourist_request):
    eventbridge = boto3.client('events')
    
    # Trigger multiple agents in parallel
    events = [
        {
            'Source': 'agent.coordinator',
            'DetailType': 'Tourist Request',
            'Detail': json.dumps({
                'request_id': tourist_request['id'],
                'agent': 'tourist_understanding',
                'data': tourist_request
            })
        }
    ]
    
    eventbridge.put_events(Entries=events)
```

### 3. AWS Bedrock Integration

#### AI Model Configuration
- **Primary Model**: Claude 3 Haiku for fast responses
- **Fallback Model**: Claude 3 Sonnet for complex queries
- **Use Cases**: 
  - Natural language understanding of tourist preferences
  - Guide matching and ranking
  - Cultural context and recommendations
  - Sentiment analysis for reviews

#### Translation Service
- **Amazon Translate**: Real-time message translation between languages
- **Supported Languages**: English, Thai, Chinese, Japanese, Korean, Spanish, French, German
- **Integration**: Direct API calls from n8n workflows
- **Caching**: Store common translations in DynamoDB for performance

#### Bedrock Lambda Integration
```python
# Pure AWS Lambda Bedrock integration
import boto3
import json

def process_with_bedrock(user_message, context):
    bedrock = boto3.client('bedrock-runtime')
    
    prompt = f"""
    Analyze this tourist request and extract:
    - Location preferences
    - Activity interests  
    - Group size and composition
    - Budget range
    - Language requirements
    - Cultural considerations
    
    Tourist message: "{user_message}"
    Context: {json.dumps(context)}
    """
    
    response = bedrock.invoke_model(
        modelId='eu.anthropic.claude-3-7-sonnet-20250219-v1:0',
        body=json.dumps({
            'anthropic_version': 'bedrock-2023-05-31',
            'messages': [{'role': 'user', 'content': prompt}],
            'max_tokens': 1000
        })
    )
    
    return json.loads(response['body'].read())
```

### 4. Database Design

#### DynamoDB Table Structure

**Users Table**
```json
{
  "TableName": "ThaiGuideBot_Users",
  "KeySchema": [
    { "AttributeName": "userId", "KeyType": "HASH" }
  ],
  "AttributeDefinitions": [
    { "AttributeName": "userId", "AttributeType": "S" },
    { "AttributeName": "platform", "AttributeType": "S" },
    { "AttributeName": "createdAt", "AttributeType": "S" }
  ],
  "GlobalSecondaryIndexes": [
    {
      "IndexName": "platform-created-index",
      "KeySchema": [
        { "AttributeName": "platform", "KeyType": "HASH" },
        { "AttributeName": "createdAt", "KeyType": "RANGE" }
      ]
    }
  ]
}
```

**Guides Table**
```json
{
  "TableName": "ThaiGuideBot_Guides",
  "KeySchema": [
    { "AttributeName": "guideId", "KeyType": "HASH" }
  ],
  "AttributeDefinitions": [
    { "AttributeName": "guideId", "AttributeType": "S" },
    { "AttributeName": "location", "AttributeType": "S" },
    { "AttributeName": "rating", "AttributeType": "N" },
    { "AttributeName": "status", "AttributeType": "S" }
  ],
  "GlobalSecondaryIndexes": [
    {
      "IndexName": "location-rating-index",
      "KeySchema": [
        { "AttributeName": "location", "KeyType": "HASH" },
        { "AttributeName": "rating", "KeyType": "RANGE" }
      ]
    },
    {
      "IndexName": "status-index",
      "KeySchema": [
        { "AttributeName": "status", "KeyType": "HASH" }
      ]
    }
  ]
}
```

**Bookings Table**
```json
{
  "TableName": "ThaiGuideBot_Bookings",
  "KeySchema": [
    { "AttributeName": "bookingId", "KeyType": "HASH" }
  ],
  "AttributeDefinitions": [
    { "AttributeName": "bookingId", "AttributeType": "S" },
    { "AttributeName": "touristId", "AttributeType": "S" },
    { "AttributeName": "guideId", "AttributeType": "S" },
    { "AttributeName": "bookingDate", "AttributeType": "S" },
    { "AttributeName": "status", "AttributeType": "S" }
  ],
  "GlobalSecondaryIndexes": [
    {
      "IndexName": "tourist-date-index",
      "KeySchema": [
        { "AttributeName": "touristId", "KeyType": "HASH" },
        { "AttributeName": "bookingDate", "KeyType": "RANGE" }
      ]
    },
    {
      "IndexName": "guide-date-index", 
      "KeySchema": [
        { "AttributeName": "guideId", "KeyType": "HASH" },
        { "AttributeName": "bookingDate", "KeyType": "RANGE" }
      ]
    }
  ]
}
```

### 5. Media Storage Architecture

#### S3 Bucket Structure
```
thailand-guide-bot-media/
├── guide-videos/
│   ├── {guideId}/
│   │   ├── intro-en.mp4
│   │   ├── intro-th.mp4
│   │   └── intro-zh.mp4
├── guide-photos/
│   ├── {guideId}/
│   │   ├── profile.jpg
│   │   └── gallery/
├── user-uploads/
│   ├── {userId}/
│   │   └── {timestamp}-{filename}
└── system-assets/
    ├── qr-codes/
    └── marketing/
```

#### Media Processing Workflow
- **Upload**: Direct to S3 with presigned URLs
- **Processing**: Lambda functions for video compression and image optimization
- **CDN**: CloudFront distribution for fast global delivery
- **Security**: Time-limited signed URLs for private content

## Data Models

### User Profile Model
```typescript
interface UserProfile {
  userId: string;
  platform: 'whatsapp' | 'line';
  phoneNumber: string;
  preferredLanguage: string;
  userType: 'tourist' | 'guide';
  profile: {
    name?: string;
    location?: string;
    preferences?: TouristPreferences | GuideProfile;
  };
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
}

interface TouristPreferences {
  interests: string[];
  budgetRange: { min: number; max: number; currency: string };
  groupSize: number;
  travelDates: { start: string; end: string };
  preferredLanguages: string[];
  accessibility: string[];
}

interface GuideProfile {
  specialties: string[];
  languages: { language: string; proficiency: string; videoUrl?: string }[];
  experience: number;
  certifications: string[];
  availability: AvailabilitySchedule;
  pricing: { baseRate: number; currency: string; rateType: string };
  location: { city: string; regions: string[] };
  rating: number;
  reviewCount: number;
  status: 'pending' | 'approved' | 'suspended' | 'inactive';
}
```

### Booking Model
```typescript
interface Booking {
  bookingId: string;
  touristId: string;
  guideId: string;
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  bookingDetails: {
    date: string;
    duration: number;
    location: string;
    activities: string[];
    groupSize: number;
    specialRequests?: string;
  };
  pricing: {
    basePrice: number;
    commission: number;
    totalPrice: number;
    currency: string;
  };
  communication: {
    touristPlatform: 'whatsapp' | 'line';
    guidePlatform: 'whatsapp' | 'line';
    conversationId?: string;
  };
  timestamps: {
    created: string;
    confirmed?: string;
    completed?: string;
    cancelled?: string;
  };
  review?: {
    rating: number;
    comment?: string;
    submittedAt: string;
  };
}
```

### Message Model
```typescript
interface Message {
  messageId: string;
  conversationId: string;
  senderId: string;
  recipientId: string;
  platform: 'whatsapp' | 'line';
  messageType: 'text' | 'image' | 'video' | 'audio' | 'location' | 'quick_reply';
  content: {
    text?: string;
    mediaUrl?: string;
    location?: { latitude: number; longitude: number };
    quickReply?: { payload: string; title: string };
  };
  metadata: {
    language?: string;
    translated?: boolean;
    aiProcessed?: boolean;
  };
  timestamp: string;
  status: 'sent' | 'delivered' | 'read' | 'failed';
}
```

## Error Handling

### Error Classification
1. **Platform Errors**: WhatsApp/LINE API failures
2. **AI Processing Errors**: Bedrock timeouts or failures  
3. **Database Errors**: DynamoDB throttling or connection issues
4. **Integration Errors**: External API failures
5. **Business Logic Errors**: Invalid booking states, user conflicts

### Error Handling Strategy
```javascript
// n8n error handling configuration
const errorHandling = {
  retryPolicy: {
    maxRetries: 3,
    backoffStrategy: 'exponential',
    baseDelay: 1000
  },
  fallbackActions: {
    'bedrock_timeout': 'use_cached_response',
    'dynamodb_throttle': 'queue_for_retry',
    'platform_api_error': 'notify_user_and_log'
  },
  alerting: {
    criticalErrors: ['payment_failure', 'data_corruption'],
    notificationChannels: ['email', 'slack']
  }
};
```

### Graceful Degradation
- **AI Unavailable**: Fall back to keyword-based matching
- **Database Issues**: Use cached data and queue writes
- **Platform Outages**: Store messages for delayed delivery
- **Payment Failures**: Provide alternative payment methods

## Testing Strategy

### Unit Testing
- **n8n Workflows**: Test individual nodes and workflow logic
- **Data Models**: Validate schema and business rules
- **Integration Functions**: Mock external API responses

### Integration Testing  
- **Platform APIs**: Test webhook handling and message delivery
- **AWS Services**: Validate Bedrock responses and DynamoDB operations
- **Cross-Platform**: Test message routing between WhatsApp and LINE

### End-to-End Testing
- **User Journeys**: Complete tourist and guide workflows
- **Booking Process**: Full booking lifecycle testing
- **Quality Assurance**: Guide registration and review processes

### Performance Testing
- **Load Testing**: Simulate high message volumes
- **Latency Testing**: Measure response times for AI processing
- **Scalability Testing**: Test auto-scaling of n8n workflows

### Local Development Environment
```yaml
# Docker Compose for AWS services testing
version: '3.8'
services:
  localstack:
    image: localstack/localstack
    environment:
      - SERVICES=lambda,dynamodb,s3,events,sqs,apigateway
      - DEBUG=1
      - LAMBDA_EXECUTOR=docker
      - DOCKER_HOST=unix:///var/run/docker.sock
    ports:
      - "4566:4566"
    volumes:
      - "/var/run/docker.sock:/var/run/docker.sock"
      
  dynamodb-local:
    image: amazon/dynamodb-local
    ports:
      - "8000:8000"
    command: ["-jar", "DynamoDBLocal.jar", "-sharedDb", "-inMemory"]
```

### AWS SAM Local Testing
```yaml
# template.yaml for SAM local testing
AWSTemplateFormatVersion: '2010-09-09'
Transform: AWS::Serverless-2016-10-31

Resources:
  TouristAgent:
    Type: AWS::Serverless::Function
    Properties:
      CodeUri: src/agents/tourist/
      Handler: handler.lambda_handler
      Runtime: python3.9
      Environment:
        Variables:
          BEDROCK_MODEL_ID: anthropic.claude-3-5-sonnet-20240620-v1:0
```

## Deployment Architecture

### Development Environment
- **AWS SAM Local**: Local Lambda function testing
- **LocalStack**: Mock AWS services for development
- **DynamoDB Local**: Local database for testing
- **ngrok**: Tunnel for WhatsApp webhook testing

### Production Environment
- **AWS Lambda**: Serverless function execution
- **API Gateway**: RESTful API management
- **EventBridge**: Event-driven architecture
- **DynamoDB**: NoSQL database with auto-scaling
- **S3**: Object storage with CloudFront CDN
- **CloudWatch**: Monitoring and logging

### Infrastructure as Code with Terraform
```hcl
# Terraform configuration for pure AWS serverless
resource "aws_lambda_function" "tourist_agent" {
  filename         = "tourist_agent.zip"
  function_name    = "${var.project_name}-tourist-agent"
  role            = aws_iam_role.lambda_execution.arn
  handler         = "handler.lambda_handler"
  runtime         = "python3.9"
  timeout         = 30

  environment {
    variables = {
      BEDROCK_MODEL_ID = "anthropic.claude-3-5-sonnet-20240620-v1:0"
      USERS_TABLE = aws_dynamodb_table.users.name
    }
  }
}

resource "aws_api_gateway_rest_api" "main" {
  name        = "${var.project_name}-api"
  description = "Global Guide Bot API"
}

resource "aws_events_rule" "agent_coordination" {
  name        = "${var.project_name}-agent-coordination"
  description = "Routes messages between agents"
  
  event_pattern = jsonencode({
    source = ["whatsapp.webhook", "agent.coordinator"]
  })
}
```

### Monitoring and Observability
- **CloudWatch**: Comprehensive metrics, logs, and alarms for all Lambda functions
- **X-Ray**: Distributed tracing for agent communication flows
- **EventBridge Monitoring**: Event delivery and processing metrics
- **Custom Dashboards**: Agent performance, booking success rates, and user satisfaction KPIs
- **Lambda Insights**: Performance monitoring and optimization recommendations

### AWS Service Integration Benefits
- **Zero Third-Party Dependencies**: 100% AWS services for maximum reliability
- **Serverless Scaling**: Automatic scaling based on demand
- **Event-Driven Architecture**: Loose coupling between agents for better maintainability
- **Cost Optimization**: Pay-per-use model with no idle resources
- **Security**: AWS IAM for fine-grained access control
- **Compliance**: Built-in AWS security and compliance features

This design provides a **hackathon-winning, pure AWS serverless foundation** for the Global Guide Bot with advanced multi-agent capabilities, comprehensive monitoring, and zero external dependencies - perfect for showcasing AWS AI and serverless technologies.